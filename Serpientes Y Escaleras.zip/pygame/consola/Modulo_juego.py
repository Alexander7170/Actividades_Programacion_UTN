
def pedir_dato(mensaje:str)->str:
    return input(mensaje)

def validar_string(string:str,opcion1:str, opcion2:str)->str:
    """
    Funcion que obliga al usuario a que el string sea igual a una de la dos opciones

    Parametros:
        string: la cadena de caracter, que validaremos con una de las dos opciones
        opcion1: Una cadena de caracteres, que es la primera opcion que puede tomar el string
        opcion2: Una cadena de caracteres, que es la segunda opcion que puede tomar el string
    RETORNO:
        devuelve un string igual a una de las dos opciones
    """
    string = string.lower()
    while string != opcion1 and string != opcion2:
        string = input("ponga dentro de las opciones " + opcion1 + "/" + opcion2 + "  :  ").lower()
    return string

def verificar_palabra(palabra:str, palabra_a_comparar:str)->bool:
    """
    Funcion que verifica si la primera palabra es igual a la segunda palabra pasado como paremetro

    Parametros:
        palabra: un string que la que compararemos con la otra palabra
        palabra_a_comparar: un string que se usara como la comparacion de la otra palabra
    Retorno:
        Devuelve un booleano verdadero si ambas palabras son iguales, sino devuelve falso 
    """
    palabras_iguales = False
    if palabra == palabra_a_comparar:
        palabras_iguales = True
    return palabras_iguales

def imprimir_valores(pregunta_opciones:dict):
    """
    Funcion que imprime valores de algunas claves del diccionario

    Parametros:
        pregunta_opciones: el diccionario cuyo valores imprimiremos 
    """
    print("pregunta: ", pregunta_opciones["pregunta"], "\n a:", pregunta_opciones["respuesta_a"], "\n b:",pregunta_opciones["respuesta_b"], "\n c:", pregunta_opciones["respuesta_c"])

def pedir_dato_para_pregunta(mensaje:str)->str:
    """
    Funcion que pide un dato que sea "a", "b" o "c"
    devuelve una de esos 3 caracteres
    """
    dato = input(mensaje).lower()
    while dato != "a" and dato != "b" and dato != "c":
        dato = input("error, " + mensaje).lower()
    return dato

def verificar_respuesta(pregunta:dict, respuesta:str, clave_respuesta:str)->bool:
    """
    Funcion que verifica si el parametro respuesta es igual al valor dentro de una clave

    Parametros:
        Pregunta: un diccionario donde se encuentra esa clave
        respuesta: el valor string que compararemos con el valor dentro de la clave
        clave_respuesta: un string que indicara la clave en donde vericaremos
    Retorno:
        Devuelve un booleano verdadero si el valor respuesta es igual al valor dentro de la clave, sino devuelve falso
    """
    acerto = False
    respuesta = respuesta.lower()
    if pregunta[clave_respuesta] == respuesta:
        acerto = True
    return acerto

def manejar_pregunta(lista:list)->dict:
    """
    Funcion que busca aleatoriamente un diccionario dentro de la listay la elimina de la lista:
    parametros:
        lista: Lista de diccionarios donde buscaremos un diccionario aleatoriamente
    Retorno:
        devuelve un diccionario cualquiera dentro de la lista
    """
    import random
    pregunta = random.choice(lista)
    lista.remove(pregunta)
    return pregunta

def guardar_score(nombre:str, puntuacion:int):
    """
    Funcion que anexa el nombre y la puntuacion del usuario en un archivo

    Parametros:

    nombre: un string que seria el nombre del usuario y el que primero anexaremos

    puntuacion: un entero que seria el indice del usuario y el segundo que anexaremos
    """
    archivo = open("score.csv", "a")
    archivo.write(nombre + "," + str(puntuacion) + "\n")
    archivo.close()

def mover_usuario(acerto:bool, indice_usuario:int)->int:
    """
    funcion que mueve al usuario dependien de un criterio, si es verdadero el usuario avanza
    si el falso el usuario retrocede

    Parametros:
        indice_usuario: un entero que determina en donde esta parado el usuario
        acerto: un booleano que determina si el usuario tiene que avanzar o retroceder
    Retorno:
        devuelve un entero que indicaria la posicion donde quedo el usuario
    """
    if acerto:
        indice_usuario += 1
    else:
        indice_usuario -= 1
    return indice_usuario

def mover_extra_usuario(acerto:bool, indice_usuario:int, tablero:list)->int:
    """
    Funcion que mueve al usuario dependiendo del valor donde este en el tablero y si acerto o no

    Parametros:
        acerto: un booleano que determina si avanza o retrocede
        indice_usuario: un entero que indica la posicion del usuario
        tablero: una lista que representa el tablero 
    """
    if acerto:
        indice_usuario += tablero[indice_usuario]
    else:
        indice_usuario -= tablero[indice_usuario]
    return indice_usuario

def validar_indice_usuario(indice_usuario:int,tablero:list)->int:
    """
    funcion que valida al indice usuario en el tablero
    Parametros:
        indice_usuario: un entero, indica la posicion del usuario
        tablero: una lista, indica el tablero
    Retorno:
        devuelve el indice del usuario dentro del tablero
    """
    if indice_usuario > len(tablero)-1:
        indice_usuario = 30
    elif indice_usuario < 0:
        indice_usuario = 0
    return indice_usuario

def verificar_fin_juego(indice_usuario:int, tablero:list, preguntas:list)->bool:
    """
    Funcion que verifica si el juego ya a concluido o aun sigue en pie
    
    Parametros:
        indice_usuario: un entero que determina la posicion actual del usuario
        tablero: una lista de enteros, representa el tablero
        preguntas: una lista de diccionaros, representan las preguntas que aun quedas

    Retorno:
        Devuelve un booleano verdadero si el usuario quedo en el ultimo casillero o en el primero
        o si la lista de preguntas esta vacia, sino devuelve falso
    """
    fin_juego = False
    if indice_usuario == 0 or len(preguntas) == 0 or indice_usuario == len(tablero)-1:
        fin_juego = True
    return fin_juego

def jugar_turno(indice_usuario:int, tablero:list, criterio:bool)->int:
    """
    Funcion que controla el indice del usuario, moviendolo y validandolo dentro del tablero
    Parametros:
        indice_usuario: un entero que determina la posicion del usuario
        tablero: una lista que determina el tablero
        criterio: un booleano que determina si el usuario avanza o retrocede
    Retorno:
        devuelve el indice del usuario
    """

    indice_usuario = mover_usuario(criterio,indice_usuario)
    indice_usuario = validar_indice_usuario(indice_usuario,tablero)
    indice_usuario = mover_extra_usuario(criterio,indice_usuario,tablero)
    return indice_usuario

def analizar_dato()->bool:
    """
    Funcion que llama a otras funciones, con el objetivo de obtener una respuesta del usuario
    validarlo en don opciones, y verificarlo si dijo una opcion

    Retorno:
        devuelve un booleano, si el usuario quiere jugar o no
    """
    dato = pedir_dato("Quiere jugar ?(si/no): ")
    dato = validar_string(dato,"si","no")
    return dato